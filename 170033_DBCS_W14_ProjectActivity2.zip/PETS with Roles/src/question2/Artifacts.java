package question2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Artifacts {

	public static void insertArtifacts(String name, String desc) throws Exception {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/project_lifecycles_database?useSSL=false", "root", "SparshGoel@12345");

			Statement stmt = conn.createStatement();

			String insert = "INSERT INTO tb_artifacts (artifacts_Name, artifacts_Description) VALUES ('" + name + "', '"
					+ desc + "');";
			stmt.executeUpdate(insert);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}